"use client";
import Link from "next/link";
import { FormEvent, useEffect, useRef, useState } from "react";

type Msg = { role: "teacher" | "student"; text: string };

export default function ChatPage() {
  const [messages, setMessages] = useState<Msg[]>([{ role: "teacher", text: "你好！我是小语老师。很高兴陪你练习中文！你可以用中文或英语和我交流。我会根据你的水平帮助你表达得更自然。今天想聊些什么？" }]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const rec = useRef<any>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { setSupported(false); return; }
    const r = new SR(); r.lang = "zh-CN"; r.interimResults = false; r.continuous = false;
    r.onresult = (e: any) => { const t = e.results?.[0]?.[0]?.transcript || ""; setInput(t); setListening(false); };
    r.onerror = () => setListening(false); r.onend = () => setListening(false); rec.current = r;
  }, []);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, sending]);

  function speak(text: string) {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text); u.lang = "zh-CN"; u.rate = 0.9; window.speechSynthesis.speak(u);
  }

  async function send(event?: FormEvent) {
    event?.preventDefault();
    const text = input.trim();
    if (!text || sending) return;
    const nextMessages: Msg[] = [...messages, { role: "student", text }];
    setMessages(nextMessages); setInput(""); setError(""); setSending(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages.map(({ role, text: messageText }) => ({ role, text: messageText })) }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error || "暂时无法连接 AI 老师，请稍后重试。");
      const reply = String(data.reply || "").trim();
      if (!reply) throw new Error("这次没有收到回复，请再试一次。");
      setMessages(current => [...current, { role: "teacher", text: reply }]);
      speak(reply);
    } catch (err) {
      setError(err instanceof Error ? err.message : "发生了意外错误，请重试。");
    } finally { setSending(false); }
  }

  return <main className="app-shell"><nav className="nav"><Link className="brand" href="/">☯ 小语老师</Link><Link href="/">返回首页</Link></nav>
    <section className="chat-wrap"><div className="chat-head"><div className="avatar-small">语</div><div><h1>和小语老师聊天</h1><p><span className="online"></span> AI 中文老师 · 文字对话</p></div></div>
      <div className="chat-area">{messages.map((m, i) => <div key={i} className={`bubble-row ${m.role}`}><div className="bubble-avatar">{m.role === "teacher" ? "语" : "我"}</div><div className="bubble" style={{ whiteSpace: "pre-wrap" }}>{m.text}</div></div>)}
        {sending && <div className="bubble-row teacher"><div className="bubble-avatar">语</div><div className="bubble">小语老师正在思考…</div></div>}
        <div ref={bottomRef}/>
      </div>
      {error && <p role="alert" style={{ color: "#b45309", padding: "0 16px" }}>{error}</p>}
      <form className="composer" onSubmit={send}><button type="button" className={`mic ${listening ? "active" : ""}`} disabled={!supported || sending} onClick={() => { if (!rec.current) return; if (listening) { rec.current.stop(); setListening(false); } else { setListening(true); rec.current.start(); } }} title="语音输入">🎙</button><input value={input} onChange={e => setInput(e.target.value)} placeholder={supported ? "输入中文或英语，或点击麦克风说话…" : "当前浏览器不支持语音识别，请输入文字"} disabled={sending}/><button className="send" type="submit" disabled={sending || !input.trim()}>{sending ? "发送中…" : "发送"}</button></form>
      <p className="privacy">AI 对话需要网络连接；语音输入由浏览器提供，中文朗读由设备提供。{listening ? " 正在聆听…" : ""}</p>
    </section>
  </main>;
}

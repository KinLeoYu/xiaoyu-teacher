# 小语老师 · 中文口语练习网站

## 本地运行
1. 安装 Node.js 20 或更新版本。
2. 在项目目录运行 `npm install`。
3. 在部署环境配置 `OPENAI_API_KEY`（不要写入代码或提交到 GitHub）。
4. 运行 `npm run dev`，打开 http://localhost:3000。

## 当前功能
- 首页、聊天页、发音练习页
- AI 中文老师文字对话（通过服务端 `/api/chat` 调用 OpenAI Responses API）
- AI 根据外国学习者需求进行中文纠错、英语辅助解释和例句教学
- 浏览器语音识别与设备中文语音朗读（支持情况取决于浏览器和设备）
- 发音练习页面保留现有基础功能；尚未提供专业自动发音评分

## 部署到 Vercel
1. 将项目上传到 GitHub。
2. 在 Vercel 导入仓库，Framework 选择 Next.js。
3. 如果项目文件位于 `xiaoyu-teacher-project` 子目录，Root Directory 选择该目录。
4. 在 Vercel → Project → Settings → Environment Variables 中添加：
   - Name: `OPENAI_API_KEY`
   - Value: 你在 OpenAI 平台创建的 API Key
   - Environment: Production（建议同时勾选 Preview）
5. 保存后进入 Deployments，对最新部署执行 Redeploy；也可以提交新代码触发自动部署。

可选环境变量：`OPENAI_MODEL`，默认 `gpt-5.5`。通常不需要设置。

## 安全提醒
- 绝对不要把真实 API Key 写入前端代码、`.env.example` 或 GitHub。
- API Key 只放在 Vercel 服务端环境变量中。
- AI 使用会产生独立的 API 费用，请在 OpenAI 平台设置预算/使用提醒。
- 当前版本没有登录、用户配额或防滥用系统。正式公开推广前，建议增加访问频率限制和用量控制，避免 API 被滥用。
